# WBG Technology & Innovation Radar

A static, interactive technology-intelligence edition for WBG development, ITS capabilities and the wider frontier. This expanded edition contains **37 trends, 102 startups, scaleups and ecosystem builders, 17 concrete use cases, 31 dated signals and 200 source entries**, checked on **23 November 2026**.

## Purpose and structure

The radar helps a visitor understand what is changing, why it could matter and which builders are worth examining. It has three substantive perspectives, each with its own six sectors:

- **WBG development:** public services and inclusion; climate and Earth; agriculture and food; health, skills and jobs; energy and infrastructure; finance, firms and trade.
- **ITS & enterprise:** software and modernization; knowledge and agents; data and forecasting; trust and identity; cloud and reliability; models and interfaces.
- **Frontier:** work and agents; models and interfaces; agent foundations; physical and spatial AI; science and simulation; compute and quantum.

The main views are Radar, Trends, Use cases, Startups and Recent signals. A larger desktop radar has an Expand radar control for a full-width canvas; its signal details open in a keyboard-accessible dialog. The directory supports comparison of up to three builders, a local shortlist and CSV export. A guided introduction and the About view explain how to read the evidence and identify remaining coverage gaps.

## Run and host

Serve `dist/` with a static web server. There is no build step, external JavaScript dependency, application backend, account database or embedded credential.

**Azure or GitHub Pages can host the colleague-facing site.** See [DEPLOY_ON_AZURE.md](DEPLOY_ON_AZURE.md) to update the existing Azure app, or [DEPLOY_ON_GITHUB.md](DEPLOY_ON_GITHUB.md) for a dedicated GitHub Pages website. The source repository retains the earlier Sites manifest for source management; that manifest is excluded from the publication package.

```bash
python3 scripts/compile_research.py
node --check dist/app.js
python3 scripts/package_azure.py /absolute/path/outside/the/checkout/wbg-radar-release-v3.zip
python3 scripts/deploy_azure.py --validate-package
python3 scripts/deploy_azure.py --publish
```

The final command needs an authorized Azure CLI session and Node.js. It verifies the existing application's hostname, keeps its deployment credential in memory, uploads the reviewed assets and verifies served asset hashes before reporting success. It does not create another Azure app.

## Source layout

- `dist/index.html`, `styles.css`, `app.js`: responsive interface, SVG radar, navigation, dialogs, local shortlist, comparison and exports.
- `dist/data.js` and `data.json`: identical checked research payloads in browser and portable formats.
- `dist/staticwebapp.config.json`: static hosting, MIME types, cache and response headers for Azure.
- `dist/build.json`: release identifier, counts and SHA-256 hashes generated at packaging time.
- `research/frontier.json`, `wbg.json`: original checked research.
- `research/frontier-v2.json`, `wbg-v2.json`: expanded primary-source research and product-availability qualifications.
- `research/editorial-v2.json`: explicit editorial choices, practical applications, comparison questions and use-case briefs.
- `research/lens-domains-v2.json`: context-specific radar sectors and their trend mapping.
- `research/coverage-wbg-v3.json`, `coverage-its-v3.json`: targeted additions for jobs and skills, productive small firms, digital public infrastructure, document intelligence and AI governance.
- `scripts/compile_research.py`, `augment_research.py`, `augment_coverage.py`: normalization, coverage structure and cross-reference validation.
- `.github/workflows/pages.yml`: GitHub Pages publication of the reviewed static assets.

## What the rings mean

- **Now:** products or methods are available to explore in a bounded setting; local suitability still needs validation.
- **Next:** practical use is emerging, with integration, reliability or deployment evidence still developing.
- **Horizon:** broader relevance depends on substantial technical, economic or operational milestones.

These are editorial judgments about potential relevance. They are not fixed-year forecasts, adoption decisions, supplier rankings or maturity certifications. A company's actual public availability is shown separately. Early access, qualified-customer availability, research programs and future roadmaps remain explicitly qualified.

Potential WBG/ITS uses and use-case briefs are analysis. Sources establish public capabilities and context, not WBG deployments, partnerships or endorsements. EIDU, eGov Foundation/DIGIT, Mojaloop Foundation and implementation specialists are included as ecosystem builders without invented funding stages. Company-reported results are not presented as independently tested performance.

This is a curated landscape, not a census of every startup or WBG sector. The coverage note identifies areas for deeper research, including manufacturing, tourism, urban mobility, housing and country-specific implementation evidence. New profiles must add a distinct, relevant capability, not merely increase the count.

## Research maintenance

This is a dated research snapshot, not a continuously updated feed. Publication dates and last-checked dates are separate fields. Unknown publication dates remain null. Never change a checked date merely because files were rebuilt.

For a new edition, read primary product and institutional sources; recheck identity, acquisitions and product availability; update the raw research and deliberate editorial files; preserve stable IDs; run the compiler; review the rendered experience; regenerate the release package; then publish through the authorized hosting account.

The compiler rejects duplicate IDs, missing associations, unknown perspective sectors, missing evidence, non-HTTPS sources and publication dates beyond the cutoff. Source claims and suggested uses stay in separate fields. Do not add unsupported funding totals, headcounts, efficacy claims or WBG relationships.

Design references: [Thoughtworks Technology Radar](https://www.thoughtworks.com/radar), [Zalando Tech Radar](https://opensource.zalando.com/tech-radar/) and [DHL Logistics Trend Radar](https://www.dhl.com/us-en/home/innovation-in-logistics/logistics-trend-radar.html). Their experience-based adoption judgments have not been copied as WBG adoption claims.

## Privacy and brand

The static application does not send searches, shortlists or exported data to a backend. Shortlists remain in the visitor's browser and do not synchronize across devices. The content uses public sources and excludes internal audit findings, staff contact details and unpublished internal material from the old radar.

The World Bank Group logo retains its original proportions and colors. The asset came from [the Wikimedia file record](https://commons.wikimedia.org/wiki/File:World_Bank_Group_logo.svg), which attributes the WBG author and cites the [original WBG SVG](https://www.worldbank.org/content/dam/wbr/logo/wbg-logo-about-en.svg). WBG trademarks remain their owner's property.
