# WBG Technology & Innovation Radar

A static, interactive technology-intelligence edition for WBG development, ITS capabilities and the wider frontier. This expanded edition contains **37 trends, 102 startups, scaleups and ecosystem builders, 17 concrete use cases, 32 dated signals and 214 source entries**. The broad landscape was checked on **23 November 2026**; five company spotlights, WBG references and selected evidence were refreshed on **24 November 2026**.

## Purpose and structure

The homepage is the **interactive radar**. Visitors select WBG, ITS or Frontier perspectives, click an area to explore its companies and trends, and open named records with official startup websites and relevant WBG articles. Search, horizon filters, label display, an expanded radar, a matching-results list, comparison and a personal shortlist support exploration. **Copy this view** preserves the selected perspective and filters in a shareable URL.

The **Share / QR** panel provides a verified QR code for the stable public homepage, in PNG and SVG formats, plus a WBG-branded poster. The QR always opens the interactive radar. The separate copied-view link retains the visitor's current filters. QR assets are in `dist/assets/`.

The separate `showcase.html` page is the cinematic studio for presentations and hologram displays. It has **12 trend scenes, 5 company close-ups, 63 featured builders and a 180-second loop**, with six WBG development scenes, four ITS scenes and two frontier scenes. Readable startup names rotate across the wider landscape; all 102 names appear during the complete default loop. Five animated camera moves zoom into Sarvam AI, SatSure, Factory, Reducto and LILA Sciences, explain three capabilities, then connect them to separately documented WBG work. Each of the 12 trend scenes also carries a named WBG reference.

Screen mode uses a 16:9 composition with a large radar and a changing insight. Hologram mode uses a square black canvas with essential content inside a circular safe area. Cinema view removes the controls. Mirror is an explicit option for reflected displays. Match the actual hologram manufacturer's dimensions, orientation, codec and projection template; this is a front-facing film, not a four-face pyramid template.

Two H264 MP4 films, 30fps and 180 seconds, are included: `dist/radar-hologram-1080.mp4` (1080 × 1080) and `dist/radar-widescreen-1080.mp4` (1920 × 1080). Custom browser recording uses MP4/H264 when supported and WebM otherwise. There is no audio. The storyboard was reviewed on 24 November; the research-wide date remains 23 November, with individual new checks recorded separately.

Earlier `research.html` links redirect to the interactive homepage while preserving their filters and record links. Earlier root cinema links with `?mode=hologram&clean=1` redirect to `showcase.html` with their display settings preserved. The two MP4 file addresses are unchanged.

The radar helps a visitor understand what is changing, why it could matter and which builders are worth examining. It has three substantive perspectives, each with its own six sectors:

- **WBG development:** public services and inclusion; climate and Earth; agriculture and food; health, skills and jobs; energy and infrastructure; finance, firms and trade.
- **ITS & enterprise:** software and modernization; knowledge and agents; data and forecasting; trust and identity; cloud and reliability; models and interfaces.
- **Frontier:** work and agents; models and interfaces; agent foundations; physical and spatial AI; science and simulation; compute and quantum.

The main views are Radar, Trends, Use cases, Startups and Recent signals. A larger desktop radar has an Expand radar control for a full-width canvas; its signal details open in a keyboard-accessible dialog. The directory supports comparison of up to three builders, a local shortlist and CSV export. A guided introduction and the About view explain how to read the evidence and identify remaining coverage gaps.

## Run and host

Serve `dist/` with a static web server. There is no build step, external JavaScript dependency, application backend, account database or embedded credential.

**Azure or GitHub Pages can host the colleague-facing site.** See [DEPLOY_ON_AZURE.md](DEPLOY_ON_AZURE.md) to update the existing Azure app, or [DEPLOY_ON_GITHUB.md](DEPLOY_ON_GITHUB.md) for a dedicated GitHub Pages website. The source repository retains the earlier Sites manifest for source management; that manifest is excluded from the publication package.

```bash
python3 scripts/compile_research.py
python3 scripts/compile_showcase.py
node --check dist/app.js
python3 scripts/package_azure.py /absolute/path/outside/the/checkout/wbg-radar-release-v5.zip
python3 scripts/deploy_azure.py --validate-package
python3 scripts/deploy_azure.py --publish
```

The final command needs an authorized Azure CLI session and Node.js. It verifies the existing application's hostname, keeps its deployment credential in memory, uploads the reviewed assets and verifies served asset hashes before reporting success. It does not create another Azure app.

## Source layout

- `dist/index.html`, `styles.css`, `app.js`: interactive explorer, named radar, area overviews, WBG references, filters, shortlist, comparison and share/QR controls.
- `dist/showcase.html`, `showcase.css`, `showcase-app.js`: cinematic studio, playback, clean display mode, evidence dialogs and recording controls.
- `dist/showcase-renderer.js`, `showcase-model.js`: shared deterministic canvas and scene selection for website and films.
- `dist/showcase-export.js`: browser MediaRecorder and PNG exports.
- `dist/showcase-data.js`, `showcase-data.json`: 17-segment storyboard (12 trend scenes + 5 company close-ups) with linked source IDs.
- `research/showcase-v5.json`, `research/showcase-refresh-v5.json`, `scripts/compile_showcase.py`: canonical storyboard, dated research overlay, validation and idempotent source merging.
- `scripts/render_showcase_video.mjs`: offline PNG/H264 rendering from the identical model and canvas, using Node.js, `@napi-rs/canvas` and FFmpeg.
- `dist/research.html`, `entry-route.js`: compatibility redirects for earlier research and cinema URLs.
- `dist/assets/radar-qr.png`, `radar-qr.svg`, `radar-qr-poster.png`, `radar-qr-poster.svg`: verified public-homepage QR and WBG-branded print/share artwork.
- `dist/data.js` and `data.json`: identical checked research payloads in browser and portable formats.
- `dist/staticwebapp.config.json`: static hosting, MIME types, cache and response headers for Azure.
- `dist/build.json`: release identifier, counts and SHA-256 hashes generated at packaging time.
- `research/frontier.json`, `wbg.json`: original checked research.
- `research/frontier-v2.json`, `wbg-v2.json`: expanded primary-source research and product-availability qualifications.
- `research/editorial-v2.json`: explicit editorial choices, practical applications, comparison questions and use-case briefs.
- `research/lens-domains-v2.json`: context-specific radar sectors and their trend mapping.
- `research/coverage-wbg-v3.json`, `coverage-its-v3.json`: targeted additions for jobs and skills, productive small firms, digital public infrastructure, document intelligence and AI governance.
- `scripts/compile_research.py`, `augment_research.py`, `augment_coverage.py`: normalization, coverage structure and cross-reference validation.
- `.github/workflows/pages.yml`: GitHub Pages publication of the reviewed static assets.

## What the rings mean

- **Now:** products or methods are available to explore in a bounded setting; local suitability still needs validation.
- **Next:** practical use is emerging, with integration, reliability or deployment evidence still developing.
- **Horizon:** broader relevance depends on substantial technical, economic or operational milestones.

These are editorial judgments about potential relevance. They are not fixed-year forecasts, adoption decisions, supplier rankings or maturity certifications. A company's actual public availability is shown separately. Early access, qualified-customer availability, research programs and future roadmaps remain explicitly qualified.

Potential WBG/ITS uses and use-case briefs are analysis. Sources establish public capabilities and context, not WBG deployments, partnerships or endorsements. EIDU, eGov Foundation/DIGIT, Mojaloop Foundation and implementation specialists are included as ecosystem builders without invented funding stages. Company-reported results are not presented as independently tested performance.

This is a curated landscape, not a census of every startup or WBG sector. The coverage note identifies areas for deeper research, including manufacturing, tourism, urban mobility, housing and country-specific implementation evidence. New profiles must add a distinct, relevant capability, not merely increase the count.

## Research maintenance

This is a dated research snapshot, not a continuously updated feed. Publication dates and last-checked dates are separate fields. Unknown publication dates remain null. Never change a checked date merely because files were rebuilt.

For a new edition, read primary product and institutional sources; recheck identity, acquisitions and product availability; update the raw research and deliberate editorial files; preserve stable IDs; run the compiler; review the rendered experience; regenerate the release package; then publish through the authorized hosting account.

The compiler rejects duplicate IDs, missing associations, unknown perspective sectors, missing evidence, non-HTTPS sources and publication dates beyond the cutoff. Source claims and suggested uses stay in separate fields. Do not add unsupported funding totals, headcounts, efficacy claims or WBG relationships.

Design references: [Thoughtworks Technology Radar](https://www.thoughtworks.com/radar), [Zalando Tech Radar](https://opensource.zalando.com/tech-radar/) and [DHL Logistics Trend Radar](https://www.dhl.com/us-en/home/innovation-in-logistics/logistics-trend-radar.html). Their experience-based adoption judgments have not been copied as WBG adoption claims.

## Privacy and brand

The static application does not send searches, shortlists or exported data to a backend. Shortlists remain in the visitor's browser and do not synchronize across devices. The content uses public sources and excludes internal audit findings, staff contact details and unpublished internal material from the old radar.

The World Bank Group logo retains its original proportions. The showcase uses a white monochrome rendering on black; the research interface keeps the original colors. The asset came from [the Wikimedia file record](https://commons.wikimedia.org/wiki/File:World_Bank_Group_logo.svg), which attributes the WBG author and cites the [original WBG SVG](https://www.worldbank.org/content/dam/wbr/logo/wbg-logo-about-en.svg). WBG trademarks remain their owner's property.

## Company close-up edition and typography

The loop is 180 seconds: 12 trend scenes at 10 seconds each, plus 5 company close-ups at 12 seconds each. The camera moves to the company’s plotted point before showing its functions and the WBG connection. Company capabilities and documented WBG work are separately sourced; suggested use does not establish adoption, procurement suitability or endorsement. The broader research cutoff remains 23 November, and the selected refresh is dated 24 November.

The official WBG vector artwork preserves the Andes logotype. Body text uses the corporate secondary Arial family; the films are rendered with actual Arial Regular and Bold. The browser requests locally available Arial, then Helvetica and the system sans-serif fallback. Main accents use WBG bright blue (`#009FDA`) and navy (`#002244`), alongside the domain palette. Logo clear space is protected from the sweep. Reference: [WBG visual identity guide](https://thedocs.worldbank.org/en/doc/723361567518322252-0060022019/render/WBGBrandingandVisualIdentityGuidelinesFebruary2016.pdf).

To render with your licensed local Arial files (font binaries are intentionally excluded from the web deployment):

```bash
node scripts/render_showcase_video.mjs --format square --font-dir /absolute/path/to/arial --fps 30 --output /absolute/new-square-film.mp4
```

The helper requires `Arial.TTF`/`arial.ttf` and `Arialbd.TTF`/`arialbd.ttf`; it does not silently substitute another font. Both provided MP4s contain rasterized text, not font files.
