# Restore the finished films before deployment

This source archive contains the website, research, storyboard, renderer and deployment instructions. The two finished films are distributed separately to keep this source download small.

Download these files and save them in `dist/` with the filenames below before deploying the complete site:

- `radar-hologram-1080.mp4`: https://omakhlouk.github.io/wbg-technology-radar/radar-hologram-1080.mp4?v=2026.11.24.5
- `radar-widescreen-1080.mp4`: https://omakhlouk.github.io/wbg-technology-radar/radar-widescreen-1080.mp4?v=2026.11.24.5

Alternatively, render them with `scripts/render_showcase_video.mjs` and licensed local Arial fonts. Font files are not included. Regenerate `dist/build.json` with the packaging script after restoring or rendering the films.
