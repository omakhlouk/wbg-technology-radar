# Publish the WBG radar through GitHub Pages

The radar is a static website. It can be published through either the existing Azure Static Web App or a dedicated GitHub Pages repository. Publishing through GitHub Pages creates a separate website address; it does not update the existing Azure URL.

## Dedicated repository

Use a dedicated repository such as `wbg-technology-radar` in the intended GitHub account. The publication package contains public-source research only. A public repository supports GitHub Pages on GitHub Free; private-repository availability depends on the account plan.

Preserve the supplied directory structure, including `dist/` and `.github/workflows/pages.yml`. The workflow publishes only the static website in `dist/`. The research and maintenance scripts are optional for hosting, but useful for future editions.

In the repository, open **Settings → Pages → Build and deployment** and select **GitHub Actions** as the source. Push the reviewed release to `main`, or run **Publish WBG technology radar** manually from the Actions tab.

The Actions deployment output reports the exact website URL. Wait for a successful deployment and inspect the published `build.json` release identifier before sharing the link. A repository URL alone is not a deployed radar.

## Future updates

1. Edit the checked research files and retain primary-source URLs and dates.
2. Run `python3 scripts/compile_research.py` to validate and regenerate the data.
3. Run `python3 scripts/package_azure.py /tmp/wbg-radar-release.zip` to regenerate the release manifest. The same `dist/` works on both hosts.
4. Commit and push the reviewed changes. The workflow publishes updates to `dist/` automatically.

The `targetHost` in `build.json` is the safeguard used by the Azure deployment helper; it does not redirect the site or prevent GitHub Pages hosting. Assets and record links use paths relative to the current website.

Official instructions: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
