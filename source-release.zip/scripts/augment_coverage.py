"""Add targeted WBG/ITS coverage, preserving source-backed distinctions."""
import json
from pathlib import Path
from urllib.parse import urlparse

from augment_research import validate_v2

ROOT = Path(__file__).resolve().parents[1]
EDITION = '2026.11.23.3'


def apply_coverage(data):
    previous = {key: len(data[key]) for key in ('trends', 'companies')}
    previous['version'] = data['meta']['version']
    for name in ('coverage-wbg-v3.json', 'coverage-its-v3.json'):
        addition = json.loads((ROOT / 'research' / name).read_text())
        for item in addition.get('newTrends', addition.get('proposedTrends', addition.get('trends', []))):
            data['trends'].append({**item, 'addedInEdition': EDITION})
        for item in addition.get('companies', []):
            data['companies'].append({**item, 'addedInEdition': EDITION})
        data['sources'].extend({k: v for k, v in item.items() if k not in {'ref', 'citationRef'}} for item in addition.get('sources', []))
        data['opportunities'].extend(addition.get('opportunities', []))
        for signal in addition.get('signals', []):
            data['signals'].append({**signal, 'trendId': signal.get('trendId') or signal['trendIds'][0], 'text': signal.get('text') or signal['summary']})
        for key, changes in addition.get('trendOverrides', {}).items():
            next(item for item in data['trends'] if item['id'] == key).update(changes)
    trend_map = {item['id']: item for item in data['trends']}
    company_map = {item['id']: item for item in data['companies']}
    fallback = {'experiment': 'now', 'assess': 'next', 'watch': 'horizon'}
    for trend in data['trends']:
        trend.setdefault('horizon', fallback[trend['ring']])
        trend['companyIds'] = [item['id'] for item in data['companies'] if trend['id'] in item['trendIds']]
    for company in data['companies']:
        primary = trend_map[company['trendIds'][0]]
        company.setdefault('horizon', primary['horizon'])
        company.setdefault('evidenceLabel', 'Company product information')
        company.setdefault('evidenceNote', company.get('note', ''))
        company.setdefault('note', company.get('evidenceNote', ''))
        company.setdefault('region', '')
        company.setdefault('availability', 'Verify availability for the intended setting using the linked product information.')
        company.setdefault('domainsByLens', {})
        for lens in company['lenses']:
            matches = [trend_map[tid]['domainsByLens'][lens] for tid in company['trendIds'] if lens in trend_map[tid]['domainsByLens']]
            assert matches, (company['id'], lens, 'Missing domain mapping')
            company['domainsByLens'].setdefault(lens, matches[0])
    sector_changes = {
        'wbg-health': {'name': 'Health, skills & jobs', 'shortName': 'Health, skills & jobs', 'description': 'Support health, learning, skills development and access to employment.'},
        'wbg-decisions': {'name': 'Finance, firms & trade', 'shortName': 'Finance, firms & trade', 'description': 'Improve financial inclusion, productive firms, supervision and the evidence used for decisions.'},
    }
    for sector in data['lensDomains']['wbg']:
        sector.update(sector_changes.get(sector['id'], {}))
    for item in data['opportunities']:
        if not item.get('sourceIds'):
            item['sourceIds'] = list(dict.fromkeys(source for rid in item['trendIds'] for source in trend_map[rid]['sourceIds']))
            item['sourceIds'] = list(dict.fromkeys(item['sourceIds'] + [source for rid in item['companyIds'] for source in company_map[rid]['sourceIds']]))
        item.setdefault('evidenceNote', 'Proposed application. Sources establish capabilities and context, not a WBG implementation or endorsement.')
    for source in data['sources']:
        source.setdefault('date', None)
        source.setdefault('checked', data['meta']['checked'])
        source.setdefault('kind', 'Primary source')
        source.setdefault('publisher', (urlparse(source['url']).hostname or '').removeprefix('www.'))
        source.setdefault('note', '')
    events = {}
    for signal in sorted(data['signals'], key=lambda item: item['date'] or '', reverse=True):
        events.setdefault((signal['date'], tuple(sorted(signal['sourceIds']))), signal)
    data['signals'] = list(events.values())
    data['meta'].update({
        'version': EDITION,
        'previousEdition': previous,
        'coverageSummary': 'A curated starting point, not an exhaustive market map. Coverage connects WBG development priorities with institutional technology needs and consequential frontier advances. It is strongest in AI and enterprise software, digital public services, climate and Earth observation, energy and infrastructure, health and learning, financial inclusion, skills and productive firms. The directory includes startups, scaleups and explicitly identified public-good builders because relevant digital infrastructure is not built by companies alone.',
        'coverageGaps': [
            'Tourism and value-added manufacturing beyond a small number of examples.',
            'Urban mobility, housing and municipal waste.',
            'Gender, disability accessibility and fragility-specific service delivery.',
            'Country-by-country deployment, procurement and total-cost evidence.'
        ]
    })
    validate_v2(data)
    return data
