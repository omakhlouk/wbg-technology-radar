"""Merge the expanded, checked research and deliberate editorial structure."""
import json
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]


def unique(records, label):
    ids = [r['id'] for r in records]
    assert len(ids) == len(set(ids)), f'Duplicate {label} ID'
    return set(ids)


def apply_v2(data):
    editorial = json.loads((ROOT / 'research/editorial-v2.json').read_text())
    additions = [json.loads((ROOT / path).read_text()) for path in ('research/frontier-v2.json', 'research/wbg-v2.json')]
    opportunities = list(editorial['opportunities'])
    for addition in additions:
        for item in addition.get('newTrends', addition.get('proposedTrends', addition.get('trends', []))):
            data['trends'].append({**item, 'addedInEdition': editorial['meta']['version']})
        for item in addition.get('companies', []):
            data['companies'].append({**item, 'addedInEdition': editorial['meta']['version']})
        for source in addition.get('sources', []):
            data['sources'].append({k: v for k, v in source.items() if k not in {'ref', 'citationRef'}})
        for signal in addition.get('signals', []):
            data['signals'].append({**signal, 'trendId': signal.get('trendId') or signal['trendIds'][0], 'text': signal.get('text') or signal['summary']})
        opportunities.extend(addition.get('opportunities', []))
    trend_map = {t['id']: t for t in data['trends']}
    company_map = {c['id']: c for c in data['companies']}
    for key, fields in editorial['trendOverrides'].items():
        trend_map[key].update(fields)
    for key, fields in editorial['companyOverrides'].items():
        company_map[key].update(fields)
    fallback = {'experiment': 'now', 'assess': 'next', 'watch': 'horizon'}
    for trend in data['trends']:
        trend['horizon'] = editorial['horizons'].get(trend['id'], trend.get('horizon', fallback[trend['ring']]))
        trend['companyIds'] = [c['id'] for c in data['companies'] if trend['id'] in c['trendIds']]
        trend.setdefault('evidenceLabel', 'Source-linked technology research')
    for company in data['companies']:
        primary = trend_map[company['trendIds'][0]]
        company.setdefault('horizon', primary['horizon'])
        company.setdefault('evidenceLabel', 'Company product information')
        company.setdefault('evidenceNote', company.get('note', ''))
        company.setdefault('region', '')
        company.setdefault('note', company.get('evidenceNote', ''))
        company.setdefault('availability', 'See the linked product information and verify availability for the intended setting.')
    # Keep these physical-infrastructure themes accessible through the development lens,
    # without implying a particular deployment or endorsing a supplier.
    for tid in ('ai-engineering-simulation',):
        if 'wbg' not in trend_map[tid]['lenses']:
            trend_map[tid]['lenses'].append('wbg')
    for opportunity in opportunities:
        opportunity.setdefault('sourceIds', [])
        if not opportunity['sourceIds']:
            ids = []
            for key in opportunity['trendIds']:
                ids.extend(trend_map[key]['sourceIds'])
            for key in opportunity['companyIds']:
                ids.extend(company_map[key]['sourceIds'])
            opportunity['sourceIds'] = list(dict.fromkeys(ids))
        opportunity['evidenceNote'] = 'Proposed application. Linked sources describe capabilities and context; this is not evidence of a WBG implementation.'
    data['meta'].update(editorial['meta'])
    data['meta']['previousEdition'] = {'version': '2026.11.23', 'trends': 22, 'companies': 64}
    data['meta']['horizonMeaning'] = {
        'now': 'Products or methods are available to explore in a bounded setting; suitability still needs local validation.',
        'next': 'Practical use is emerging, with integration, reliability or deployment evidence still developing.',
        'horizon': 'Broader relevance depends on substantial technical, economic or operational milestones.'
    }
    data['opportunities'] = opportunities
    data['benchmarks'] = editorial['benchmarks']
    lens_structure = json.loads((ROOT / 'research/lens-domains-v2.json').read_text())
    data['lensDomains'] = lens_structure['domains']
    for trend in data['trends']:
        trend['domainsByLens'] = lens_structure['trendDomains'][trend['id']]
    for company in data['companies']:
        company['domainsByLens'] = {}
        for lens in company['lenses']:
            matches = [trend_map[tid]['domainsByLens'][lens] for tid in company['trendIds'] if lens in trend_map[tid]['domainsByLens']]
            assert matches, (company['id'], lens, 'Missing domain mapping')
            company['domainsByLens'][lens] = matches[0]
    # Deduplicate dated events, keeping the newest event first.
    events = {}
    for signal in sorted(data['signals'], key=lambda s: s['date'] or '', reverse=True):
        events.setdefault((signal['date'], tuple(sorted(signal['sourceIds']))), signal)
    data['signals'] = list(events.values())
    for source in data['sources']:
        source.setdefault('date', None)
        source.setdefault('checked', data['meta']['checked'])
        source.setdefault('kind', 'Primary source')
        source.setdefault('publisher', (urlparse(source['url']).hostname or '').removeprefix('www.'))
        source.setdefault('note', '')
    validate_v2(data)
    return data


def validate_v2(data):
    domains = unique(data['domains'], 'domain')
    trends = unique(data['trends'], 'trend')
    companies = unique(data['companies'], 'company')
    sources = unique(data['sources'], 'source')
    unique(data['opportunities'], 'opportunity')
    cutoff = data['meta']['checked']
    for record in data['trends'] + data['companies']:
        assert record['domain'] in domains, record['id']
        assert record['horizon'] in {'now', 'next', 'horizon'}, record['id']
        assert record['lenses'] and set(record['lenses']) <= {'wbg', 'its', 'frontier'}, record['id']
        assert record['sourceIds'] and set(record['sourceIds']) <= sources, record['id']
        assert record['summary'] and record['verified'] <= cutoff, record['id']
        for lens in record['lenses']:
            assert record['domainsByLens'].get(lens) in {d['id'] for d in data['lensDomains'][lens]}, (record['id'], lens)
    for trend in data['trends']:
        assert trend['companyIds'] and set(trend['companyIds']) <= companies, trend['id']
        for key in ('title', 'summary', 'whyNow', 'application', 'experiment', 'measure'):
            assert trend.get(key), (trend['id'], key)
    for company in data['companies']:
        assert company['trendIds'] and set(company['trendIds']) <= trends, company['id']
        assert urlparse(company['website']).scheme == 'https', company['id']
    for record in data['opportunities']:
        assert record['companyIds'] and set(record['companyIds']) <= companies, record['id']
        assert record['trendIds'] and set(record['trendIds']) <= trends, record['id']
        assert record['sourceIds'] and set(record['sourceIds']) <= sources, record['id']
        assert record['lenses'] and set(record['lenses']) <= {'wbg', 'its', 'frontier'}, record['id']
        for key in ('title', 'problem', 'users', 'outcome', 'approach', 'experiment', 'measure'):
            assert record.get(key), (record['id'], key)
    for source in data['sources']:
        assert urlparse(source['url']).scheme == 'https', source['id']
        assert not source['date'] or source['date'][:10] <= cutoff, source['id']
        assert source['checked'][:10] <= cutoff, source['id']
    for signal in data['signals']:
        assert signal['trendId'] in trends, signal['title']
        assert set(signal['sourceIds']) <= sources and signal['sourceIds'], signal['title']
        assert signal['date'] <= cutoff, signal['title']
