#!/usr/bin/env python3
"""Deploy the reviewed static package to the existing, hostname-verified Azure app.

Uses the caller's Azure CLI session. Deployment credentials remain in memory.
No resource is created; no access policy or account configuration is changed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from urllib.parse import quote, urlparse

APP_NAME = "oie-radar"
RESOURCE_GROUP = "compliance-ai-kg"
EXPECTED_HOST = "thankful-mushroom-0dd1f610f.1.azurestaticapps.net"
ROOT = Path(__file__).resolve().parents[1]


def run_json(args):
    result = subprocess.run(args, capture_output=True, text=True, check=False)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or "The Azure command failed.")
    return json.loads(result.stdout)


def validate_package(directory):
    if Path(directory).is_symlink():
        raise RuntimeError('The deployment directory must not be a symbolic link.')
    directory = Path(directory).resolve()
    members = list(directory.rglob('*'))
    if any(p.is_symlink() for p in members):
        raise RuntimeError('The deployment directory must not contain symbolic links.')
    for name in ("index.html", "app.js", "styles.css", "data.js", "data.json", "build.json"):
        if not (directory / name).is_file():
            raise RuntimeError(f"The deployment package is missing {name}.")
    data = json.loads((directory / "data.json").read_text())
    build = json.loads((directory / "build.json").read_text())
    if build.get("targetHost") != EXPECTED_HOST:
        raise RuntimeError("This package identifies a different Azure destination.")
    actual_files = {str(p.relative_to(directory)) for p in members if p.is_file() and p != directory / 'build.json'}
    if set(build.get('sha256', {})) != actual_files:
        raise RuntimeError('The asset manifest must cover every uploaded file exactly.')
    for name, expected in build.get("sha256", {}).items():
        path = (directory / name).resolve()
        if not path.is_relative_to(directory) or not path.is_file():
            raise RuntimeError(f"Invalid package asset: {name}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"The package changed after validation: {name}")
    if not build.get("sha256"):
        raise RuntimeError("The package has no verified asset manifest.")
    expected_counts = {k: len(data.get(k, [])) for k in ("trends", "companies", "sources", "opportunities")}
    if build.get("counts") != expected_counts:
        raise RuntimeError("Research counts differ from the release manifest.")
    return directory, build


def locate_app(subscription=None):
    if not shutil.which("az"):
        raise RuntimeError("Azure CLI is required. Use Azure Cloud Shell, or install Azure CLI and run az login on your Mac.")
    try:
        account = run_json(["az", "account", "show", "--output", "json", "--only-show-errors"])
    except RuntimeError as exc:
        raise RuntimeError("An Azure sign-in is required. Run az login, then run this deployment command again.") from exc
    subscriptions = [subscription] if subscription else [account["id"]]
    if not subscription:
        visible = run_json(["az", "account", "list", "--output", "json", "--only-show-errors"])
        subscriptions += [s["id"] for s in visible if s.get("state") == "Enabled" and s["id"] not in subscriptions]
    found = []
    for sid in subscriptions:
        try:
            app = run_json(["az", "staticwebapp", "show", "--name", APP_NAME,
                            "--resource-group", RESOURCE_GROUP, "--subscription", sid,
                            "--output", "json", "--only-show-errors"])
        except RuntimeError:
            continue
        if app.get("defaultHostname") == EXPECTED_HOST:
            found.append((sid, app))
    if len(found) != 1:
        raise RuntimeError("Could not uniquely verify the existing oie-radar app and its exact hostname in the signed-in account. No deployment was attempted.")
    return found[0]


def verify_release(build):
    url = "https://" + EXPECTED_HOST + "/build.json?release=" + build["release"]
    for attempt in range(6):
        try:
            request = urllib.request.Request(url, headers={"Cache-Control": "no-cache"})
            with urllib.request.urlopen(request, timeout=15) as response:
                if urlparse(response.url).hostname != EXPECTED_HOST or urlparse(response.url).scheme != 'https':
                    raise ValueError('Release verification redirected to a different host.')
                remote = json.load(response)
            if remote.get("release") == build["release"] and remote.get("sha256") == build["sha256"]:
                for name, expected in build['sha256'].items():
                    # Azure consumes the hosting configuration; it is not a public asset.
                    if name == 'staticwebapp.config.json':
                        continue
                    asset_url = 'https://' + EXPECTED_HOST + '/' + quote(name, safe='/') + '?release=' + build['release']
                    asset_request = urllib.request.Request(asset_url, headers={'Cache-Control': 'no-cache'})
                    with urllib.request.urlopen(asset_request, timeout=15) as response:
                        if urlparse(response.url).hostname != EXPECTED_HOST or urlparse(response.url).scheme != 'https':
                            raise ValueError('Asset verification redirected to a different host.')
                        actual = hashlib.sha256(response.read()).hexdigest()
                    if actual != expected:
                        raise ValueError('A served asset does not yet match this release.')
                print("Verified the new release at https://" + EXPECTED_HOST + "/")
                return True
        except (urllib.error.URLError, ValueError):
            pass
        if attempt < 5:
            time.sleep(5)
    print("Azure accepted the upload; the new release could not yet be verified through the public URL. Check the Azure deployment status before declaring it live.")
    return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, default=ROOT / "dist")
    parser.add_argument("--subscription", help="Optional Azure subscription ID; otherwise find the exact app in accessible subscriptions.")
    parser.add_argument("--publish", action="store_true", help="Upload to the verified existing production app.")
    parser.add_argument("--validate-package", action="store_true", help="Check the local release without contacting Azure.")
    args = parser.parse_args()
    directory, build = validate_package(args.assets)
    print("Release:", build["release"])
    print("Research:", ", ".join(str(v) + " " + k for k, v in build["counts"].items()))
    print("Destination: https://" + EXPECTED_HOST + "/")
    if args.validate_package:
        print("Local package integrity passed. Azure was not contacted.")
        return 0
    sid, app = locate_app(args.subscription)
    print("Verified existing Azure app:", app["name"], "in", RESOURCE_GROUP)
    if not args.publish:
        print("Ready. Add --publish to upload this package to production.")
        return 0
    if not shutil.which("npx"):
        raise RuntimeError("Node.js with npx is required for Microsoft's Static Web Apps CLI.")
    token = run_json(["az", "staticwebapp", "secrets", "list", "--name", APP_NAME,
                      "--resource-group", RESOURCE_GROUP, "--subscription", sid,
                      "--output", "json", "--only-show-errors"])["properties"]["apiKey"]
    if not token:
        raise RuntimeError("Azure did not return a deployment credential. No upload was attempted.")
    deploy_env = os.environ.copy()
    deploy_env["SWA_CLI_DEPLOYMENT_TOKEN"] = token
    command = ["npx", "--yes", "@azure/static-web-apps-cli@latest", "deploy", str(directory),
               "--env", "production", "--no-use-keychain", "--verbose", "silent"]
    print("Uploading the reviewed package to Azure production…")
    result = subprocess.run(command, env=deploy_env, capture_output=True, text=True, check=False)
    message = (result.stdout + result.stderr).replace(token, "[redacted]").strip()
    deploy_env.pop("SWA_CLI_DEPLOYMENT_TOKEN", None)
    token = None
    if result.returncode:
        raise RuntimeError(message or "Azure Static Web Apps CLI did not complete deployment.")
    if message:
        print(message)
    return 0 if verify_release(build) else 2


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (RuntimeError, KeyError, ValueError) as exc:
        print("Deployment stopped:", exc, file=sys.stderr)
        sys.exit(1)
