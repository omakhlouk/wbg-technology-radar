"""Validate the three-minute film and merge its dated, targeted research refresh."""
import json
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / 'dist/data.json').read_text())
story = json.loads((ROOT / 'research/showcase-v5.json').read_text())
refresh = json.loads((ROOT / 'research/showcase-refresh-v5.json').read_text())

# A repeatable merge, preserving the broader landscape's original checked date.
source_map = {item['id']: item for item in data['sources']}
for item in refresh['sources']:
    assert urlparse(item['url']).scheme == 'https'
    source_map[item['id']] = {key: value for key, value in item.items() if key != 'retrievalRef'}
for update in refresh['sourceUpdates']:
    source_map[update['id']].update(update)
data['sources'] = list(source_map.values())
company_map = {item['id']: item for item in data['companies']}
for change in refresh['companyPatches']:
    company = company_map[change['companyId']]
    company.update({key: value for key, value in change.items() if key not in {'companyId','appendSourceIds'}})
    company['sourceIds'] = list(dict.fromkeys(company['sourceIds'] + change.get('appendSourceIds',[])))
for spot in refresh['spotlights']:
    company = company_map[spot['companyId']]
    company['sourceIds'] = list(dict.fromkeys(company['sourceIds'] + spot['sourceIds']))
    company['verified'] = refresh['meta']['checked']
data['meta'].update(version=story['meta']['version'],spotlightsChecked=refresh['meta']['checked'],refreshScope=refresh['meta']['scope'])
new_signal = {'title':'Speech and documents become structured workflow inputs','date':'2026-11-24','text':'Sarvam released Extract on 24 November after Dictate on 23 November. Explore service access and document workflows with field-level evidence and human review.','sourceIds':['sarvam-extract-20261124','sarvam-dictate-20261123'],'trendId':'local-language-ai'}
data['signals'] = [item for item in data['signals'] if item['title'] != new_signal['title']] + [new_signal]
data['signals'].sort(key=lambda item:item.get('date') or '',reverse=True)

seen = set()
assert len(story['scenes']) == 17
assert sum(scene['duration'] for scene in story['scenes']) == story['meta']['durationSeconds'] == 180
assert len([scene for scene in story['scenes'] if scene['kind']=='spotlight']) == 5
for scene in story['scenes']:
    assert scene['id'] not in seen
    seen.add(scene['id'])
    assert scene['lens'] in {'wbg', 'its', 'frontier'}
    for field, section in [('companyIds','companies'),('trendIds','trends'),('sourceIds','sources')]:
        ids = {item['id'] for item in data[section]}
        assert all(value in ids for value in scene[field]), (scene['id'],field)
    assert all(scene['detail'].get(key) for key in ('opportunity','proofToSeek','firstExperiment'))
    assert scene.get('wbgAnchor',{}).get('sourceIds')
    if scene['kind']=='spotlight':
        assert len(scene['companyIds']) == 1 and scene['duration'] == 12
        spot=scene['spotlight']
        assert len(spot['functionalities']) == 3
        assert max(map(len,spot['functionalities'])) < 48
        assert len(spot['application']) < 115
        assert len(spot['wbgAnchor']['shortName']) < 43
    else:
        assert 4 <= len(scene['companyIds']) <= 6 and scene['duration'] == 10
        for field, limit in [('title',42),('radarTitle',25),('claim',115),('implication',145),('watch',120)]:
            assert len(scene[field]) <= limit, (scene['id'],field)
for name, payload, global_name in [('data',data,'RADAR_DATA'),('showcase-data',story,'RADAR_SHOWCASE')]:
    text=json.dumps(payload,ensure_ascii=False,indent=2)
    (ROOT / f'dist/{name}.json').write_text(text+'\n')
    (ROOT / f'dist/{name}.js').write_text(f'window.{global_name} = '+text+';\n')
print(json.dumps({'scenes':len(story['scenes']),'spotlights':5,'featuredBuilders':len({c for s in story['scenes'] for c in s['companyIds']}),'sources':len(data['sources']),'duration':story['meta']['durationSeconds'],'version':story['meta']['version']}))
