"""Compile and validate the film storyboard against the checked radar dataset."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / 'dist/data.json').read_text())
story = json.loads((ROOT / 'research/showcase-v4.json').read_text())
assert len(story['scenes']) == 12
seen = set()
for scene in story['scenes']:
    assert scene['id'] not in seen
    seen.add(scene['id'])
    assert scene['lens'] in {'wbg', 'its', 'frontier'}
    for field, section in [('companyIds','companies'),('trendIds','trends'),('sourceIds','sources')]:
        ids = {item['id'] for item in data[section]}
        assert all(value in ids for value in scene[field]), (scene['id'],field)
    assert 4 <= len(scene['companyIds']) <= 6
    for field, limit in [('title',42),('radarTitle',25),('claim',115),('implication',145),('watch',120)]:
        assert len(scene[field]) <= limit, (scene['id'],field)
    assert all(scene['detail'].get(key) for key in ('opportunity','proofToSeek','firstExperiment'))
payload = json.dumps(story,ensure_ascii=False,indent=2)
(ROOT / 'dist/showcase-data.json').write_text(payload+'\n')
(ROOT / 'dist/showcase-data.js').write_text('window.RADAR_SHOWCASE = '+payload+';\n')
print(json.dumps({'scenes':len(story['scenes']),'featuredBuilders':len({c for s in story['scenes'] for c in s['companyIds']}),'duration':story['meta']['durationSeconds'],'version':story['meta']['version']}))
