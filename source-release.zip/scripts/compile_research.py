"""Compile checked research into the static radar payload; reject broken links."""
import json
import re
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
CHECKED = "2026-11-23"
frontier = json.loads((ROOT / "research/frontier.json").read_text())
wbg = json.loads((ROOT / "research/wbg.json").read_text())

domains = [
    {"id": "enterprise", "name": "Enterprise & work", "shortName": "Enterprise & work", "color": "#47B8F4", "description": "How agents reshape software, workflows and the way organizations operate."},
    {"id": "trust", "name": "Trust & AI foundations", "shortName": "Trust & foundations", "color": "#A6A4FF", "description": "The context, evaluation, access controls and infrastructure that make AI usable."},
    {"id": "inclusion", "name": "Digital public services", "shortName": "Digital public services", "color": "#64D6C3", "description": "Accessible services, local languages, identity and accountable supervision."},
    {"id": "climate", "name": "Climate & Earth", "shortName": "Climate & Earth", "color": "#A5D87F", "description": "Observation and evidence for resilience, natural resources and environmental decisions."},
    {"id": "resources", "name": "Energy & essentials", "shortName": "Energy & essentials", "color": "#F4C36F", "description": "Practical innovation for agriculture, health, reliable energy and water."},
    {"id": "frontier", "name": "Frontier systems", "shortName": "Frontier systems", "color": "#F19DBB", "description": "Robotics, world models and quantum capabilities to follow as evidence develops."},
]

domain_map = {
    "software-agents": "enterprise", "enterprise-agents": "enterprise", "lean-ai-native": "enterprise",
    "context-memory": "trust", "agent-interoperability": "trust", "agent-evaluation": "trust", "agentic-security": "trust", "sovereign-data-ai": "trust", "on-device-ai": "trust",
    "local-language-ai": "inclusion", "inclusive-digital-services": "inclusion", "supervisory-casework": "inclusion",
    "geospatial-intelligence": "climate", "climate-adaptation": "climate", "nature-mrv": "climate",
    "agriculture-intelligence": "resources", "frontline-health": "resources", "distributed-energy": "resources", "intelligent-water": "resources",
    "physical-ai": "frontier", "world-models": "frontier", "fault-tolerant-quantum": "frontier",
}

short_titles = {
    "local-language-ai": "Local-language AI", "geospatial-intelligence": "Earth intelligence", "climate-adaptation": "Climate adaptation",
    "sovereign-data-ai": "Local data & compute", "inclusive-digital-services": "Identity & inclusion", "agriculture-intelligence": "Agricultural intelligence",
    "frontline-health": "Frontline health", "distributed-energy": "Distributed energy", "intelligent-water": "Intelligent water",
    "nature-mrv": "Nature & carbon evidence", "supervisory-casework": "SupTech & casework",
}

lens_map = {
    "software-agents": ["its", "frontier"], "enterprise-agents": ["its"], "lean-ai-native": ["its", "frontier"],
    "context-memory": ["its"], "agent-interoperability": ["its", "frontier"], "agent-evaluation": ["its", "wbg"],
    "agentic-security": ["its"], "physical-ai": ["frontier"], "world-models": ["frontier"], "fault-tolerant-quantum": ["frontier"],
    "sovereign-data-ai": ["wbg", "its"], "on-device-ai": ["wbg", "its", "frontier"],
}

def clean_proposal(text):
    text = re.sub(r"^Proposed(?: WBG use)?:\s*", "", text)
    return (text.replace("a Reimagine intake agent", "an intake agent")
            .replace("a bounded Reimagine workflow", "a bounded process-improvement workflow")
            .replace("Use the Open Innovation Exchange to examine", "Use a founder-led demonstration to examine")
            .replace("as an operating-model case at the Exchange", "through a founder-led demonstration of one completed deliverable"))

trends = []
for t in frontier["trends"]:
    trends.append({
        "id": t["id"], "title": t["title"], "shortTitle": t["shortTitle"], "domain": domain_map[t["id"]],
        "ring": t["ring"].lower(), "lenses": lens_map[t["id"]], "summary": t["definition"], "whyNow": t["whyNow"],
        "application": clean_proposal(t["wbgExample"]), "experiment": t["experiment"], "measure": t["measure"],
        "watchouts": t["risks"], "companyIds": t["companies"], "sourceIds": t["sourceIds"], "verified": CHECKED,
    })
for t in wbg["trends"]:
    trends.append({
        "id": t["id"], "title": t["title"], "shortTitle": short_titles[t["id"]], "domain": domain_map[t["id"]],
        "ring": t["ring"].lower(), "lenses": lens_map.get(t["id"], ["wbg"]), "summary": t["definition"], "whyNow": t["why_now"],
        "application": clean_proposal(t["wbg_use"]), "experiment": t["experiment"], "measure": t["metric"],
        "watchouts": [t["risks"]] if isinstance(t["risks"], str) else t["risks"],
        "companyIds": t["company_ids"], "sourceIds": t["source_ids"], "verified": CHECKED,
    })

trends.append({
    "id": "on-device-ai", "title": "Small models and AI that runs locally", "shortTitle": "Small & on-device AI", "domain": "trust",
    "ring": "experiment", "lenses": lens_map["on-device-ai"],
    "summary": "Compact models and local runtimes perform selected AI tasks on a laptop, phone or edge device, reducing dependence on a continuous cloud connection.",
    "whyNow": "Liquid AI released its LFM3 family on 27 October 2026. Cactus now offers compact models for voice, vision and tool use; local runtimes make it easier to compare them on actual devices.",
    "application": "Test a field assistant that classifies a form or retrieves approved guidance on a modest device, with a human checking the result before it enters a public-service workflow.",
    "experiment": "Run one narrow task on a representative low-cost device with cloud fallback disabled. Compare the local model with a hosted baseline and test after disconnecting the network.",
    "measure": "Task accuracy, memory use, battery demand, response time, offline completion and total cost of maintaining the device fleet.",
    "watchouts": ["Small models can lose accuracy on unfamiliar languages and complex reasoning.", "Local inference still needs secure devices, maintained models and appropriate licenses.", "Hybrid products may send requests to the cloud; verify the exact data path and configuration."],
    "companyIds": ["liquid-ai", "cactus", "ollama"], "sourceIds": ["liquid-lfm3", "cactus-main", "ollama-faq", "wbg-digital"], "verified": CHECKED,
})
trend_by_id = {t["id"]: t for t in trends}

companies = []
for c in frontier["companies"]:
    tids = c["trendIds"]
    primary = trend_by_id[tids[0]]
    companies.append({
        "id": c["id"], "name": c["name"], "website": c["website"], "category": c["category"], "summary": c["summary"],
        "domain": primary["domain"], "ring": primary["ring"], "lenses": list(dict.fromkeys(l for tid in tids for l in trend_by_id[tid]["lenses"])),
        "trendIds": tids, "region": c.get("location", ""), "proposedUse": clean_proposal(c["proposedWbgUse"]),
        "sourceIds": c["sourceIds"], "verified": CHECKED, "availability": c.get("availability", ""), "note": c.get("evidenceNote", ""),
    })
wbg_categories = {
    "amini": "Locally governed data and AI infrastructure", "pixxel": "Hyperspectral Earth imagery", "satvu": "Thermal Earth imagery",
    "tomorrow": "Weather intelligence", "floodbase": "Flood data and risk finance", "climate-x": "Physical climate risk analytics",
    "sarvam": "Multilingual AI models", "lelapa": "African-language AI", "viamo": "Information services by phone",
    "smile-id": "Digital identity verification", "yoti": "Digital identity", "jumo": "Financial services infrastructure", "newlogic": "Digital public infrastructure implementation",
    "cropin": "Agricultural intelligence", "plantix": "Crop health AI", "pula": "Agricultural risk protection",
    "qure-ai": "Clinical imaging AI", "ilara-health": "Primary-care technology and services", "axmed": "Medicine procurement",
    "husk": "Distributed solar and storage", "nithio": "Energy financing analytics", "sun-king": "Off-grid solar",
    "fido-tech": "Acoustic water-leak intelligence", "wint": "Water monitoring and control", "source-global": "Distributed drinking-water technology",
    "chloris": "Biomass measurement", "sylvera": "Carbon data and ratings", "boomitra": "Soil-carbon measurement",
    "fna": "Financial supervisory analytics", "regulativ": "RegTech compliance automation", "quantexa": "Public-sector data and investigations",
}
for c in wbg["companies"]:
    tids = c["trend_ids"]
    primary = trend_by_id[tids[0]]
    category = wbg_categories[c["id"]]
    companies.append({
        "id": c["id"], "name": c["name"], "website": c["website"], "category": category, "summary": c["capability"],
        "domain": primary["domain"], "ring": primary["ring"], "lenses": list(dict.fromkeys(l for tid in tids for l in trend_by_id[tid]["lenses"])),
        "trendIds": tids, "region": c.get("regional_focus", ""), "location": c.get("location", ""),
        "proposedUse": clean_proposal(c["wbg_use"]), "sourceIds": c["source_ids"], "verified": c["verified"],
        "availability": "Implementation provider" if c.get("entity_type") == "Implementation provider" else "Commercial offering; verify local availability",
        "note": c.get("watch_for", ""),
    })
for c in [
    {"id": "liquid-ai", "name": "Liquid AI", "website": "https://www.liquid.ai/", "category": "Compact foundation models", "summary": "Develops compact language and multimodal models with downloadable weights and local deployment options, including the LFM3 family.", "proposedUse": "Compare a small model for form classification or approved-knowledge retrieval on representative field devices.", "sourceIds": ["liquid-lfm3"], "availability": "Downloadable model weights and hosted services"},
    {"id": "cactus", "name": "Cactus Compute", "website": "https://www.cactuscompute.com/", "category": "AI on everyday devices", "summary": "Builds compact models and deployment technology for local voice, vision and tool use on consumer and edge hardware, with optional hybrid cloud routing.", "proposedUse": "Test an accessible voice or form-processing interface under device, power and network constraints.", "sourceIds": ["cactus-main"], "availability": "Published models and developer tooling"},
    {"id": "ollama", "name": "Ollama", "website": "https://ollama.com/", "category": "Local model runtime", "summary": "Provides software to download, configure and run supported AI models locally, alongside separate cloud offerings.", "proposedUse": "Create a reproducible local-model evaluation environment for a bounded internal or public-service prototype.", "sourceIds": ["ollama-faq"], "availability": "Downloadable local runtime; cloud services separately available"},
]:
    companies.append({**c, "domain": "trust", "ring": "experiment", "lenses": lens_map["on-device-ai"], "trendIds": ["on-device-ai"], "region": "", "verified": CHECKED, "note": "Evaluate actual device performance and verify whether the selected configuration uses cloud services."})

sources = []
for s in frontier["sources"] + wbg["sources"]:
    host = urlparse(s["url"]).hostname or ""
    sources.append({
        "id": s["id"], "title": s["title"], "url": s["url"],
        "publisher": "World Bank Group" if "worldbank.org" in host else host.removeprefix("www."),
        "date": s.get("publishedDate", s.get("published")), "checked": s.get("checkedDate", s.get("verified", CHECKED)),
        "note": s.get("note", ""), "kind": "Institutional source" if "worldbank.org" in host else "Primary source",
    })
sources.extend([
    {"id": "liquid-lfm3", "title": "Introducing LFM3: Every Modality for Specialized Intelligence", "url": "https://www.liquid.ai/blog/lfm3", "publisher": "Liquid AI", "date": "2026-10-27", "checked": CHECKED, "kind": "Company announcement"},
    {"id": "cactus-main", "title": "Cactus Compute: models and on-device capabilities", "url": "https://www.cactuscompute.com/", "publisher": "Cactus Compute", "date": None, "checked": CHECKED, "kind": "Company source"},
    {"id": "ollama-faq", "title": "Ollama local runtime documentation", "url": "https://docs.ollama.com/faq", "publisher": "Ollama", "date": None, "checked": CHECKED, "kind": "Technical documentation"},
])

highlights = [
    {"title": "Software agents move into Azure workflows", "date": "2026-11-18", "text": "Factory announced Azure deployment and Azure DevOps integration. A concrete option for testing governed software delivery.", "sourceIds": ["factory-azure"], "trendId": "software-agents"},
    {"title": "Compact models broaden local AI options", "date": "2026-10-27", "text": "Liquid AI introduced LFM3. Test the quality and hardware requirements on the devices people actually use.", "sourceIds": ["liquid-lfm3"], "trendId": "on-device-ai"},
    {"title": "A new WBG digital strategy", "date": "2026-10-20", "text": "Connectivity, affordable access, useful services and practical small AI provide the development lens for this edition.", "sourceIds": ["wbg-digital"], "trendId": "local-language-ai"},
]

signals = [{"title": s["title"], "date": s["date"], "text": s["meaning"], "sourceIds": [s["sourceId"]], "trendId": s["trendId"]} for s in frontier["freshSignals"]]
signals += [{"title": s["title"], "date": s["date"], "text": s["detail"], "sourceIds": s["source_ids"], "trendId": s["trend_ids"][0]} for s in wbg["signals"]]
signals += highlights
signals.sort(key=lambda s: s["date"], reverse=True)
distinct_signals = {}
for signal in signals:
    key = (signal["date"], tuple(sorted(signal["sourceIds"])))
    distinct_signals.setdefault(key, signal)
signals = list(distinct_signals.values())

# Keep the two directions of each relationship complete and consistent.
for trend in trends:
    trend["companyIds"] = [c["id"] for c in companies if trend["id"] in c["trendIds"]]

data = {
    "meta": {"title": "WBG Technology & Innovation Radar", "checked": CHECKED, "edition": "November 2026", "version": "2026.11.23", "description": "Public-source research connecting emerging technologies, company capabilities and potential WBG applications.", "automaticUpdates": False},
    "domains": domains, "trends": trends, "companies": companies, "sources": sources, "highlights": highlights, "signals": signals,
}

def unique_ids(records, name):
    ids = [r["id"] for r in records]
    assert len(ids) == len(set(ids)), f"Duplicate {name} ID"
    return set(ids)

domain_ids = unique_ids(domains, "domain")
trend_ids = unique_ids(trends, "trend")
company_ids = unique_ids(companies, "company")
source_ids = unique_ids(sources, "source")
for r in trends + companies:
    assert r["domain"] in domain_ids, r["id"]
    assert r["ring"] in {"experiment", "assess", "watch"}, r["id"]
    assert r["lenses"] and set(r["lenses"]) <= {"wbg", "its", "frontier"}, r["id"]
    assert set(r["sourceIds"]) <= source_ids and r["sourceIds"], r["id"]
    assert all(r.get(k) for k in ["id", "summary", "verified"]), r["id"]
for t in trends:
    assert set(t["companyIds"]) <= company_ids and t["companyIds"], t["id"]
for c in companies:
    assert set(c["trendIds"]) <= trend_ids and c["trendIds"], c["id"]
    assert urlparse(c["website"]).scheme == "https", c["id"]
for s in sources:
    assert urlparse(s["url"]).scheme in {"http", "https"}, s["id"]
    assert not s["date"] or s["date"][:10] <= CHECKED, s["id"]
for s in signals:
    assert s["trendId"] in trend_ids and set(s["sourceIds"]) <= source_ids, s["title"]

from augment_research import apply_v2
data = apply_v2(data)
from augment_coverage import apply_coverage
data = apply_coverage(data)
payload = json.dumps(data, ensure_ascii=False, indent=2)
(ROOT / "dist/data.json").write_text(payload + "\n")
(ROOT / "dist/data.js").write_text("window.RADAR_DATA = " + payload + ";\n")
print(f"Compiled and validated {len(data['trends'])} trends, {len(data['companies'])} companies, {len(data['sources'])} sources, {len(data['domains'])} domains, {len(data['opportunities'])} use cases.")
