#!/usr/bin/env node
/** Render the website's exact canvas scene to PNG or H.264 MP4, without a browser. */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { spawn } from 'node:child_process';
import { once } from 'node:events';

const require = createRequire(import.meta.url);
const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const args = {};
for (let i = 2; i < process.argv.length; i++) {
  const flag = process.argv[i];
  if (flag === '--help') {
    console.log('Usage: node scripts/render_showcase_video.mjs --format wide|square --font-dir /absolute/arial-fonts --fps 30 --output /absolute/radar.mp4\nOptional: --duration N --width N --height N --seconds-per-scene N --lens all|wbg|its|frontier --chapter auto|ID --labels focus|all --time N (PNG). Native scene timing is used by default. Font files are local render inputs and must not be included in a web deployment.');
    process.exit(0);
  }
  if (!flag.startsWith('--') || i + 1 >= process.argv.length || process.argv[i + 1].startsWith('--')) throw new Error('Each option needs a value. Use --help.');
  args[flag.slice(2)] = process.argv[++i];
}

const format = args.format || 'wide';
if (!['wide', 'square'].includes(format)) throw new Error('Format must be wide or square.');
const width = Number(args.width || (format === 'wide' ? 1920 : 1080));
const height = Number(args.height || 1080);
const requestedDuration = args.duration === undefined ? null : Number(args.duration);
const fps = Number(args.fps || 30);
if (!Number.isInteger(width) || !Number.isInteger(height) || width < 256 || height < 256 || width > 3840 || height > 3840 || width % 2 || height % 2) throw new Error('Dimensions must be even integers between 256 and 3840.');
if ((requestedDuration !== null && (!Number.isFinite(requestedDuration) || requestedDuration <= 0 || requestedDuration > 600)) || !Number.isFinite(fps) || fps < 1 || fps > 60) throw new Error('Invalid duration or frame rate.');
if (!args.output || !path.isAbsolute(args.output)) throw new Error('Provide an absolute output path.');
const output = args.output;
if (fs.existsSync(output)) throw new Error('Output already exists. Choose a new filename so an earlier render is preserved.');
if (!/\.(png|mp4)$/i.test(output)) throw new Error('Output must end in .png or .mp4.');
fs.mkdirSync(path.dirname(output), { recursive: true });

// Render with actual Arial, the WBG secondary typeface. Keep font binaries private.
const fontDir = args['font-dir'] || process.env.RADAR_ARIAL_FONT_DIR || '/usr/share/fonts/truetype/msttcorefonts';
const fontFiles = [['Arial.TTF','arial.ttf','Arial.ttf'],['Arialbd.TTF','arialbd.ttf','Arial_Bold.ttf']].map(names => names.map(name=>path.join(fontDir,name)).find(file=>fs.existsSync(file)));
if (fontFiles.some(file=>!file)) throw new Error('Provide --font-dir containing licensed Arial Regular and Bold TTF files. No font substitution is performed.');
for (const file of fontFiles) if(!GlobalFonts.registerFromPath(file,'Arial')) throw new Error('Arial could not be loaded: '+path.basename(file));

const data = JSON.parse(fs.readFileSync(path.join(ROOT, 'dist/data.json'), 'utf8'));
const showcase = JSON.parse(fs.readFileSync(path.join(ROOT, 'dist/showcase-data.json'), 'utf8'));
const sandbox = { console, RADAR_DATA: data, RADAR_SHOWCASE: showcase };
sandbox.window = sandbox;
const context = vm.createContext(sandbox);
for (const name of ['showcase-model.js', 'showcase-renderer.js']) {
  vm.runInContext(fs.readFileSync(path.join(ROOT, 'dist', name), 'utf8'), context, { filename: name });
}
const model = sandbox.RadarShowcaseModel;
const stage = sandbox.RadarStage;
if (typeof model?.frameAt !== 'function' || typeof stage?.render !== 'function') throw new Error('The showcase model and renderer are not ready.');
const canvas = createCanvas(width, height);
const ctx = canvas.getContext('2d');
const logoPath = ['assets/wbg-logo-white.svg', 'wbg-logo-white.svg', 'assets/wbg-logo.svg'].map(name => path.join(ROOT, 'dist', name)).find(name => fs.existsSync(name));
const logo = logoPath ? await loadImage(logoPath) : null;
const modelOptions = { lens: args.lens || 'all', chapter: args.chapter || 'auto', labels: args.labels || 'focus' };
if(args['seconds-per-scene'] !== undefined) modelOptions.secondsPerScene = Number(args['seconds-per-scene']);
const duration = requestedDuration ?? model.duration(modelOptions);
const renderOptions = { format, labels: args.labels || 'focus', logo, reducedMotion: false };

function draw(timeSec) {
  const frame = model.frameAt(timeSec, modelOptions);
  stage.render(ctx, width, height, frame, renderOptions);
}

if (/\.png$/i.test(output)) {
  draw(Number(args.time || 0));
  fs.writeFileSync(output, canvas.toBuffer('image/png'));
  console.log(JSON.stringify({ output, width, height, seconds: Number(args.time || 0), bytes: fs.statSync(output).size }));
  process.exit(0);
}

const totalFrames = Math.round(duration * fps);
const ffmpeg = spawn('ffmpeg', ['-hide_banner', '-loglevel', 'warning', '-n', '-f', 'rawvideo', '-pixel_format', 'rgba', '-video_size', `${width}x${height}`, '-framerate', String(fps), '-i', 'pipe:0', '-an', '-c:v', 'libx264', '-preset', 'fast', '-crf', '19', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-metadata', 'title=WBG Technology & Innovation Radar', output], { stdio: ['pipe', 'inherit', 'inherit'] });
let encoderError = null;
ffmpeg.on('error', error => { encoderError = error; });
ffmpeg.stdin.on('error', error => { encoderError = error; });
const done = new Promise(resolve => ffmpeg.on('close', (code, signal) => resolve({ code, signal })));
const started = Date.now();
try {
  for (let i = 0; i < totalFrames; i++) {
    if (encoderError) throw encoderError;
    draw(i / fps);
    const rgba = canvas.data();
    if (!ffmpeg.stdin.write(rgba)) await once(ffmpeg.stdin, 'drain');
    if (i % Math.max(1, Math.round(fps * 5)) === 0) console.log(JSON.stringify({ frame: i, totalFrames, progress: Math.round(100 * i / totalFrames), elapsedSec: Math.round((Date.now() - started) / 1000) }));
  }
  ffmpeg.stdin.end();
  const result = await done;
  if (result.code !== 0 || encoderError) throw encoderError || new Error('FFmpeg exited with ' + result.code);
  console.log(JSON.stringify({ output, width, height, durationSec: totalFrames / fps, fps, codec: 'H.264', pixelFormat: 'yuv420p', bytes: fs.statSync(output).size, renderSeconds: Math.round((Date.now() - started) / 1000) }));
} catch (error) {
  ffmpeg.kill('SIGTERM');
  throw error;
}
