#!/usr/bin/env python3
"""Prepare a flat GitHub Pages release for a normal repository file upload."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def package(destination, source_archive):
    destination = Path(destination).resolve()
    if destination.is_relative_to(ROOT):
        raise RuntimeError('Write the publishing copy outside the source checkout.')
    destination.mkdir(parents=True, exist_ok=True)
    if any(destination.iterdir()):
        raise RuntimeError('Use an empty publishing directory.')
    dist = ROOT / 'dist'
    for name in ('app.js', 'styles.css', 'data.js', 'data.json'):
        shutil.copyfile(dist / name, destination / name)
    (destination / 'index.html').write_text((dist / 'index.html').read_text().replace('assets/wbg-logo.svg', 'wbg-logo.svg'))
    shutil.copyfile(dist / 'assets/wbg-logo.svg', destination / 'wbg-logo.svg')
    (destination / '.nojekyll').write_text('Static website; serve the reviewed files directly.\n')
    data = json.loads((dist / 'data.json').read_text())
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(destination.iterdir())}
    fingerprint = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()[:12]
    build = {'release': data['meta']['version'] + '-github-' + fingerprint,
             'researchChecked': data['meta']['checked'],
             'sourceRelease': json.loads((dist / 'build.json').read_text())['release'],
             'counts': {key: len(data[key]) for key in ('trends', 'companies', 'sources', 'opportunities')},
             'sha256': hashes}
    (destination / 'build.json').write_text(json.dumps(build, indent=2) + '\n')
    shutil.copyfile(source_archive, destination / 'source-release.zip')
    (destination / 'README.md').write_text(f'''# WBG Technology & Innovation Radar

A public-source technology and startup landscape for WBG development, ITS capabilities and the wider frontier.

This edition includes **{len(data['trends'])} trends, {len(data['companies'])} startups and ecosystem builders, {len(data['opportunities'])} use cases and {len(data['sources'])} source entries**, checked on **23 November 2026**.

## Website

GitHub Pages publishes the files in the root of the `main` branch. In Settings → Pages, the publishing source is **Deploy from a branch**, **main**, **/(root)**. Subsequent commits to the website files update the site automatically. No application server, API key or visitor account is needed.

The radar has WBG, ITS and Frontier perspectives; an animated, expandable radar; source-linked profiles; company comparison; use cases; recent signals; and a local shortlist. Its positions describe editorial assessments rather than WBG adoption. Public-good organizations are labelled separately from commercial companies. This is a curated edition, not an exhaustive or continuously refreshed market map.

## Source and maintenance

[Download the complete source and Azure deployment package](source-release.zip). The archive includes the original `dist/` layout, all checked research, the data compiler, publication instructions and both hosting options. The files at this repository root are the directly published copy; the logo reference in `index.html` is adjusted for the flat layout.

The original Azure address is a separate deployment. Publishing here does not change the Azure site.

Release: `{build['release']}`. `build.json` records hashes of the reviewed website assets.
''')
    print(json.dumps({'directory': str(destination), 'files': [p.name for p in sorted(destination.iterdir())], 'release': build['release']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination')
    parser.add_argument('source_archive')
    args = parser.parse_args()
    package(args.destination, args.source_archive)
