#!/usr/bin/env python3
"""Prepare a flat GitHub Pages release for a normal repository file upload."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]


def package(destination, source_archive):
    destination = Path(destination).resolve()
    if destination.is_relative_to(ROOT):
        raise RuntimeError('Write the publishing copy outside the source checkout.')
    destination.mkdir(parents=True, exist_ok=True)
    if any(destination.iterdir()):
        raise RuntimeError('Use an empty publishing directory.')
    dist = ROOT / 'dist'
    assets = [p for p in sorted((dist / 'assets').iterdir()) if p.is_file()]
    replacements = {str(p.relative_to(dist)): p.name for p in assets}
    for p in sorted(dist.iterdir()):
        if not p.is_file() or p.name in {'build.json','staticwebapp.config.json'}:
            continue
        target = destination / p.name
        if p.suffix in {'.html','.js','.css'}:
            content = p.read_text()
            for old, new in replacements.items():
                content = content.replace(old,new)
            target.write_text(content)
        else:
            shutil.copyfile(p,target)
    for p in assets:
        if (destination / p.name).exists():
            raise RuntimeError('Asset filename collides with a root file: '+p.name)
        shutil.copyfile(p,destination / p.name)
    (destination / '.nojekyll').write_text('Static website; serve the reviewed files directly.\n')
    data = json.loads((dist / 'data.json').read_text())
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(destination.iterdir())}
    fingerprint = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()[:12]
    story_path = dist / 'showcase-data.json'
    story = json.loads(story_path.read_text()) if story_path.exists() else None
    version = story['meta']['version'] if story else data['meta']['version']
    build = {'release': version + '-github-' + fingerprint,
             'researchChecked': data['meta']['checked'],
             'sourceRelease': json.loads((dist / 'build.json').read_text())['release'],
             'counts': {key: len(data[key]) for key in ('trends', 'companies', 'sources', 'opportunities')},
             'sha256': hashes}
    if story:
        build['showcase'] = {'scenes': len(story['scenes']), 'durationSeconds': story['meta']['durationSeconds'],
                             'featuredBuilders': len({c for scene in story['scenes'] for c in scene['companyIds']}),
                             'storyboardChecked': story['meta']['storyboardChecked'], 'spotlights': story['meta'].get('spotlightCount',0), 'trendScenes': story['meta'].get('trendSceneCount',len(story['scenes']))}
    (destination / 'build.json').write_text(json.dumps(build, indent=2) + '\n')
    # Keep the source download below GitHub's browser-upload file limit.
    # The finished films are published as separate, full-quality assets.
    with ZipFile(source_archive) as original, ZipFile(destination / 'source-release.zip', 'w', ZIP_DEFLATED) as archive:
        for member in original.infolist():
            if not member.filename.lower().endswith('.mp4'):
                archive.writestr(member.filename, original.read(member.filename))
        archive.writestr('RESTORE_FILMS.md', '''# Restore the finished films before deployment

This source archive contains the website, research, storyboard, renderer and deployment instructions. The two finished films are distributed separately to keep this source download small.

Download these files and save them in `dist/` with the filenames below before deploying the complete site:

- `radar-hologram-1080.mp4`: https://omakhlouk.github.io/wbg-technology-radar/radar-hologram-1080.mp4?v=2026.11.24.5
- `radar-widescreen-1080.mp4`: https://omakhlouk.github.io/wbg-technology-radar/radar-widescreen-1080.mp4?v=2026.11.24.5

Alternatively, render them with `scripts/render_showcase_video.mjs` and licensed local Arial fonts. Font files are not included. Regenerate `dist/build.json` with the packaging script after restoring or rendering the films.
''')
    (destination / 'README.md').write_text(f'''# WBG Technology & Innovation Radar

A cinematic technology radar for WBG development, ITS capabilities and the wider frontier.

This edition includes **{len(data['trends'])} trends, {len(data['companies'])} startups and ecosystem builders, {len(data['opportunities'])} use cases and {len(data['sources'])} source entries**. The broad landscape was checked on **23 November 2026**; the company close-ups and selected WBG references were refreshed on **24 November 2026**.

## Open the radar and films

- [Public showcase](https://omakhlouk.github.io/wbg-technology-radar/)
- [Clean square hologram view](https://omakhlouk.github.io/wbg-technology-radar/?mode=hologram&clean=1&play=1)
- [Hologram MP4: 1080 × 1080, 180 seconds](https://omakhlouk.github.io/wbg-technology-radar/radar-hologram-1080.mp4?v=2026.11.24.5)
- [Presentation MP4: 1920 × 1080, 180 seconds](https://omakhlouk.github.io/wbg-technology-radar/radar-widescreen-1080.mp4?v=2026.11.24.5)
- [Complete research library](https://omakhlouk.github.io/wbg-technology-radar/research.html)

The showcase tells a three-minute story with 12 trend scenes, 5 company close-ups and 63 featured builders. The camera zooms into Sarvam AI, SatSure, Factory, Reducto and LILA Sciences to explain functions and potential relevance to documented WBG work. Six scenes address WBG development priorities, four address ITS capabilities and two cover scientific and physical AI. Readable labels rotate through all 102 names across the full loop. The square film uses a pure black background and a circular safe area. It is a front-facing composition; match the display manufacturer's required format.

The studio provides scene selection, playback, named-company search, evidence and insight dialogs, full-screen cinema view, mirroring, PNG export and custom browser recordings. Browsers use MP4/H264 when supported and WebM otherwise. The two provided films are H264 MP4, 30fps, without audio. Storyboard reviewed 24 November 2026; the underlying research cutoff remains 23 November, with the targeted research refresh recorded separately. Every scene names a WBG reference; company applications remain proposed connections.

## Hosting

GitHub Pages publishes the files in the root of the `main` branch. In Settings → Pages, the publishing source is **Deploy from a branch**, **main**, **/(root)**. Subsequent commits to the website files update the site automatically. No application server, API key or visitor account is needed.

The research library retains WBG, ITS and Frontier perspectives, source-linked profiles, comparison, use cases, recent signals and a local shortlist. Radar positions describe editorial assessments rather than WBG adoption. Public-good organizations are labelled separately. This is a curated edition, not an exhaustive or continuously refreshed market map.

## Source and maintenance

[Download the source and deployment instructions](source-release.zip). The archive includes the original `dist/` layout, all checked research, the storyboard, data compilers and video renderer. The full-quality MP4s are separate downloads above; `RESTORE_FILMS.md` explains where to place them before deploying the complete site elsewhere. The files at this repository root are the directly published copy; logo paths are adjusted for the flat layout. To rebuild the film, use `scripts/render_showcase_video.mjs` with Node.js, `@napi-rs/canvas`, FFmpeg and `--font-dir` pointing to licensed local Arial Regular and Bold files. The films use actual Arial and the official vector WBG logotype. Font binaries are excluded from the public package.

The original Azure address is a separate deployment. Publishing here does not change the Azure site.

Release: `{build['release']}`. `build.json` records hashes of the reviewed website assets.
''')
    print(json.dumps({'directory': str(destination), 'files': [p.name for p in sorted(destination.iterdir())], 'release': build['release']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination')
    parser.add_argument('source_archive')
    args = parser.parse_args()
    package(args.destination, args.source_archive)
