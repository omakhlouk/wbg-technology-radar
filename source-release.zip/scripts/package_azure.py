#!/usr/bin/env python3
"""Create a reproducible Azure package and asset-integrity manifest."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import argparse

ROOT = Path(__file__).resolve().parents[1]
HOST = 'thankful-mushroom-0dd1f610f.1.azurestaticapps.net'


def package(output):
    dist = ROOT / 'dist'
    if dist.is_symlink():
        raise RuntimeError('The deployment directory must not be a symbolic link.')
    data = json.loads((dist / 'data.json').read_text())
    members = sorted(dist.rglob('*'))
    if any(p.is_symlink() for p in members):
        raise RuntimeError('The deployment directory must not contain symbolic links.')
    files = [p for p in members if p.is_file() and p != dist / 'build.json']
    if any('__responsive' in p.name for p in files):
        raise RuntimeError('Remove the temporary responsive-QA harness before packaging.')
    hashes = {str(p.relative_to(dist)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    fingerprint = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()[:12]
    build = {'release': data['meta']['version'] + '-' + fingerprint,
             'researchChecked': data['meta']['checked'], 'targetHost': HOST,
             'counts': {k: len(data.get(k, [])) for k in ('trends', 'companies', 'sources', 'opportunities')},
             'sha256': hashes}
    (dist / 'build.json').write_text(json.dumps(build, indent=2) + '\n')
    output = Path(output).resolve()
    if output.is_relative_to(ROOT):
        raise RuntimeError('Write the release archive outside the source checkout.')
    with ZipFile(output, 'w', ZIP_DEFLATED) as archive:
        for p in files + [dist / 'build.json']:
            archive.write(p, str(p.relative_to(ROOT)))
        source_files = ['DEPLOY_ON_AZURE.md', 'DEPLOY_ON_GITHUB.md', 'README.md', '.github/workflows/pages.yml']
        source_files += [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'scripts').glob('*.py'))]
        source_files += [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'research').glob('*.json'))]
        for name in source_files:
            archive.write(ROOT / name, name)
    with ZipFile(output) as archive:
        assert archive.testzip() is None
        assert 'dist/index.html' in archive.namelist()
    print(json.dumps({'archive': str(output), 'bytes': output.stat().st_size,
                      'release': build['release'], 'counts': build['counts']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output')
    package(parser.parse_args().output)
