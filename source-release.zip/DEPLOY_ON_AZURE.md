# Publish the revised WBG radar on Azure

## Destination

This package updates the existing **oie-radar** Static Web App in **compliance-ai-kg**, at:

https://thankful-mushroom-0dd1f610f.1.azurestaticapps.net/

The deployment helper verifies this exact hostname in your signed-in Azure account before retrieving a deployment credential. It does not create another app or change your selected subscription. Credentials stay in memory and are passed to Microsoft's CLI through an environment variable.

## Publish

Unzip the package and open its folder in Terminal. On a Mac with Azure CLI and Node.js installed, sign in to Azure if needed:

```bash
az login
```

Then run:

```bash
python3 scripts/deploy_azure.py --publish
```

The same command works from Azure Cloud Shell after uploading and extracting the package. Cloud Shell normally supplies an authenticated Azure CLI session and Node.js.

The helper locates the exact existing app, verifies the package, uploads `dist/` to **production**, and checks the deployed release manifest. If the app cannot be verified in your account, it stops before uploading. It never asks you to paste a token into chat.

To validate only the local files:

```bash
python3 scripts/deploy_azure.py --validate-package
```

To check Azure access and the destination without uploading:

```bash
python3 scripts/deploy_azure.py
```

## What is included

- `dist/`: the complete website, checked research, WBG logo and Azure configuration.
- `dist/build.json`: release identifier and SHA-256 asset hashes for post-deployment verification.
- `scripts/deploy_azure.py`: hostname-verified deployment using your Azure account.

There is no build step, application backend, AI API key, database or ongoing model cost. Shortlists are saved in each visitor's browser. The research is a dated edition and requires a new checked release to update it.

The included content is based on public sources. Proposed institutional uses are clearly identified as analysis. This edition contains no internal audit findings, staff directories or unpublished WBG documents.

## Microsoft references

- Deployment: https://learn.microsoft.com/en-us/azure/static-web-apps/static-web-apps-cli-deploy
- CLI installation: https://learn.microsoft.com/en-us/azure/static-web-apps/static-web-apps-cli-install
- Azure CLI installation: https://learn.microsoft.com/en-us/cli/azure/install-azure-cli

If Azure accepts an upload but the release check is not yet successful, inspect the deployment status before describing the new version as live. A successful sign-in or a prepared ZIP alone is not a completed deployment.
